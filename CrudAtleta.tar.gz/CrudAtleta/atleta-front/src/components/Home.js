import React from 'react';

const Home = () => {
    return <h1>Esta é a página inicial</h1>;
};

export default Home;