public class UserInfo
{
    public string Email { get; set; } = "";
    public string Password { get; set; } = "";
}
