import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <p>Página inicial</p>
    </div>
  );
}

export default App;
