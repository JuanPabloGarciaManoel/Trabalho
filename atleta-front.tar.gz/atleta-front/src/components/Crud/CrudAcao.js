const CrudAcao = {
    listar: 'listar',
    consultar: 'consultar',
    inserir: 'inserir',
    alterar: 'alterar',
    excluir: 'excluir'
};

export default CrudAcao;
